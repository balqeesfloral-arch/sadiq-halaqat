export const theme = {
  colors: {
    primary: "#0F766E",
    primaryLight: "#14B8A6",
    primaryDark: "#115E59",

    success: "#16A34A",
    warning: "#F59E0B",
    danger: "#DC2626",

    background: "#F4F8F7",
    card: "#FFFFFF",

    text: "#0F172A",
    textMuted: "#64748B",

    border: "#E2E8F0",
  },

  radius: {
    sm: 12,
    md: 18,
    lg: 24,
    xl: 32,
  },

  shadows: {
    card: "0 4px 20px rgba(15,118,110,.06)",
    hover: "0 12px 30px rgba(15,118,110,.12)",
    hero: "0 20px 50px rgba(15,118,110,.25)",
  },

  layout: {
    pagePadding: 24,
    sectionGap: 24,
    sidebarWidth: 300,
  },

  card: {
    background: "#FFFFFF",
    borderRadius: 24,
    border: "1px solid #E2E8F0",
    boxShadow: "0 4px 20px rgba(15,118,110,.06)",
  },

  hero: {
    background: "linear-gradient(135deg,#0F766E,#115E59)",
    borderRadius: 32,
    color: "#FFFFFF",
    boxShadow: "0 20px 50px rgba(15,118,110,.25)",
  },
};

export default theme;