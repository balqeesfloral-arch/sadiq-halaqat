import {
  FileText,
  BarChart3,
} from "lucide-react";

import { theme } from "../../styles/theme";

export default function ReportViewer({
  selectedReport,
}) {
  if (!selectedReport) {
    return (
      <div
        style={{
          background:
            theme.colors.surface ||
            theme.colors.card,

          borderRadius:
            theme.radius.lg,

          border: `1px solid ${theme.colors.border}`,

          boxShadow:
            theme.shadows.card,

          minHeight: "420px",

          display: "flex",
          flexDirection: "column",

          alignItems: "center",
          justifyContent: "center",

          gap: "18px",
        }}
      >
        <div
          style={{
            width: "90px",
            height: "90px",

            borderRadius: "24px",

            background: "#eef7f1",

            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <BarChart3
            size={42}
            color={
              theme.colors.primary
            }
          />
        </div>

        <h3
          style={{
            margin: 0,

            color:
              theme.colors.text,
          }}
        >
          اختر نوع التقرير
        </h3>

        <p
          style={{
            margin: 0,

            color:
              theme.colors.textSecondary,

            textAlign: "center",

            maxWidth: "400px",

            lineHeight: 1.8,
          }}
        >
          اختر أحد التقارير من الأعلى
          ثم اضغط على زر عرض التقرير
          لعرض النتائج والإحصائيات.
        </p>
      </div>
    );
  }

  return (
    <div
      style={{
        background:
          theme.colors.surface ||
          theme.colors.card,

        borderRadius:
          theme.radius.lg,

        border: `1px solid ${theme.colors.border}`,

        boxShadow:
          theme.shadows.card,

        overflow: "hidden",
      }}
    >
      <div
        style={{
          padding: "22px 24px",

          borderBottom: `1px solid ${theme.colors.border}`,

          display: "flex",
          alignItems: "center",

          gap: "14px",
        }}
      >
        <div
          style={{
            width: "52px",
            height: "52px",

            borderRadius: "14px",

            background: "#eef7f1",

            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <FileText
            size={24}
            color={
              theme.colors.primary
            }
          />
        </div>

        <div>
          <div
            style={{
              fontWeight: "800",

              fontSize: "18px",

              color:
                theme.colors.text,
            }}
          >
            معاينة التقرير
          </div>

          <div
            style={{
              color:
                theme.colors.textSecondary,

              fontSize: "13px",
            }}
          >
            التقرير المحدد حالياً
          </div>
        </div>
      </div>

      <div
        style={{
          padding: "30px",

          minHeight: "350px",
        }}
      >
        <div
          style={{
            padding: "18px",

            borderRadius: "16px",

            background: "#f8faf8",

            border:
              "1px dashed #cfd8d3",
          }}
        >
          <strong>
            التقرير المحدد:
          </strong>

          <div
            style={{
              marginTop: "10px",

              fontSize: "18px",

              color:
                theme.colors.primary,

              fontWeight: "700",
            }}
          >
            {selectedReport}
          </div>
        </div>

        <div
          style={{
            marginTop: "25px",

            color:
              theme.colors.textSecondary,

            lineHeight: 1.8,
          }}
        >
          سيتم عرض الجداول
          والإحصائيات والرسوم
          البيانية الخاصة
          بالتقرير هنا.
        </div>
      </div>
    </div>
  );
}