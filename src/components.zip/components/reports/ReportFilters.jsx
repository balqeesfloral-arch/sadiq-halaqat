export default function ReportFilters() {
  const inputStyle = {
    width: "100%",
    height: "50px",
    border: "1px solid #E5E7EB",
    borderRadius: "14px",
    padding: "0 14px",
    fontSize: "14px",
    background: "#FFFFFF",
    outline: "none",
    boxSizing: "border-box",
  };

  const labelStyle = {
    fontSize: "13px",
    fontWeight: "700",
    color: "#374151",
    marginBottom: "8px",
    display: "block",
  };

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit,minmax(250px,1fr))",
          gap: "18px",
        }}
      >
        <div>
          <label style={labelStyle}>
            من تاريخ
          </label>

          <input
            type="date"
            style={inputStyle}
          />
        </div>

        <div>
          <label style={labelStyle}>
            إلى تاريخ
          </label>

          <input
            type="date"
            style={inputStyle}
          />
        </div>

        <div>
          <label style={labelStyle}>
            المسجد
          </label>

          <select style={inputStyle}>
            <option>
              جميع المساجد
            </option>
          </select>
        </div>

        <div>
          <label style={labelStyle}>
            الحلقة
          </label>

          <select style={inputStyle}>
            <option>
              جميع الحلقات
            </option>
          </select>
        </div>

        <div>
          <label style={labelStyle}>
            المعلم
          </label>

          <select style={inputStyle}>
            <option>
              جميع المعلمين
            </option>
          </select>
        </div>

        <div>
          <label style={labelStyle}>
            الطالب
          </label>

          <select style={inputStyle}>
            <option>
              جميع الطلاب
            </option>
          </select>
        </div>
      </div>
    </div>
  );
}