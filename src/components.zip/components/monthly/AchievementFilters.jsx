import AppSelect from "../common/AppSelect";

export default function AchievementFilters({
  filters,
  setFilters,
  mosques = [],
  halaqat = [],
  teachers = []
}) {

  return (

    <div
      style={{
        background:"#fff",
        border:"1px solid #E2E8F0",
        borderRadius:"24px",
        padding:"20px",
        marginBottom:"24px"
      }}
    >

      <div
        style={{
          display:"grid",
          gridTemplateColumns:
            "repeat(5,1fr)",
          gap:"16px"
        }}
      >

        <AppSelect
          label="المسجد"
          value={filters.mosque_id}
          onChange={(value)=>
            setFilters(prev=>({
              ...prev,
              mosque_id:value
            }))
          }
          options={[
            {
              label:"جميع المساجد",
              value:""
            },
            ...mosques.map(m=>({
              label:m.name,
              value:m.id
            }))
          ]}
        />

        <AppSelect
          label="الحلقة"
          value={filters.halaqa_id}
          onChange={(value)=>
            setFilters(prev=>({
              ...prev,
              halaqa_id:value
            }))
          }
          options={[
            {
              label:"جميع الحلقات",
              value:""
            },
            ...halaqat.map(h=>({
              label:h.name,
              value:h.id
            }))
          ]}
        />

        <AppSelect
          label="المعلم"
          value={filters.teacher_id}
          onChange={(value)=>
            setFilters(prev=>({
              ...prev,
              teacher_id:value
            }))
          }
          options={[
            {
              label:"جميع المعلمين",
              value:""
            },
            ...teachers.map(t=>({
              label:t.full_name,
              value:t.id
            }))
          ]}
        />

        <div>

          <div
            style={{
              marginBottom:"8px",
              fontWeight:"700"
            }}
          >
            الشهر
          </div>

          <input
            type="month"
            value={filters.month}
            onChange={(e)=>
              setFilters(prev=>({
                ...prev,
                month:e.target.value
              }))
            }
            style={{
              width:"100%",
              height:"48px",
              border:"1px solid #CBD5E1",
              borderRadius:"12px",
              padding:"0 12px"
            }}
          />

        </div>

        <div>

          <div
            style={{
              marginBottom:"8px",
              fontWeight:"700"
            }}
          >
            البحث
          </div>

          <input
            value={filters.search}
            onChange={(e)=>
              setFilters(prev=>({
                ...prev,
                search:e.target.value
              }))
            }
            placeholder="اسم الطالب..."
            style={{
              width:"100%",
              height:"48px",
              border:"1px solid #CBD5E1",
              borderRadius:"12px",
              padding:"0 12px"
            }}
          />

        </div>

      </div>

    </div>

  );

}