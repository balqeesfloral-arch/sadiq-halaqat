import { useState } from "react";
import { X, Save, Trash2 } from "lucide-react";

import ConfirmModal from "../ConfirmModal";
import { showToast } from "../toast";

import { supabase } from "../../lib/supabase";

export default function AchievementDetailsModal({
  achievement,
  open,
  onClose,
  onUpdated
}) {

  const [loading,setLoading] =
    useState(false);

  const [showDelete,setShowDelete] =
    useState(false);

  const [form,setForm] =
    useState(achievement || {});

const progressPercent =

Math.round(

(

(form.memorization_completed ? 50 : 0)

+

(form.revision_completed ? 50 : 0)

)

);

  if(!open || !achievement)
    return null;

async function saveChanges(){

  try{

    setLoading(true);

    const { error } =
    await supabase
    .from("monthly_progress")
    .update({

      lesson_name:
      form.lesson_name,

      memorization_pages:
      form.memorization_pages,

      memorization_completed:
      form.memorization_completed,

      revision_pages:
      form.revision_pages,

      revision_completed:
      form.revision_completed,

      delay_reason:
      form.delay_reason,

      notes:
      form.notes

    })
    .eq(
      "id",
      achievement.id
    );

    if(error)
      throw error;

    showToast(
      "تم تحديث الإنجاز",
      "success"
    );

    onUpdated?.();
    onClose?.();

  }

  catch(error){

    showToast(
      error.message,
      "error"
    );

  }

  finally{

    setLoading(false);

  }

}

async function deleteAchievement(){

  try{

    const { error } =
    await supabase
    .from("monthly_progress")
    .delete()
    .eq(
      "id",
      achievement.id
    );

if(error)
  throw error;

showToast(
  "تم حذف الإنجاز",
  "success"
);

onUpdated?.();
onClose?.();

    onUpdated?.();
    onClose?.();

  }

  catch(error){

    showToast(
      error.message,
      "error"
    );

  }

} 

<div
  style={{
    background:"#F8FAFC",
    borderRadius:"20px",
    padding:"20px",
    marginBottom:"20px"
  }}
>

  <div
    style={{
      fontWeight:"800",
      marginBottom:"8px"
    }}
  >
    نسبة الإنجاز
  </div>

  <div
    style={{
      height:"12px",
      background:"#E2E8F0",
      borderRadius:"999px"
    }}
  >

    <div
      style={{
        width:`${progressPercent}%`,
        height:"100%",
        background:"#0F766E",
        borderRadius:"999px"
      }}
    />

</div>


<div
  style={{
    display:"flex",
    gap:"12px",
    marginTop:"20px"
  }}
>

  <button
    onClick={saveChanges}
  >
    <Save size={18}/>
    حفظ التعديلات
  </button>

  <button
    onClick={()=>
      setShowDelete(true)
    }
  >
    <Trash2 size={18}/>
    حذف
  </button>

</div>

<ConfirmModal
  open={showDelete}
  title="حذف الإنجاز؟"
  message="لا يمكن التراجع بعد الحذف."
  onConfirm={deleteAchievement}
  onClose={()=>
    setShowDelete(false)
  }
/>

</>
);
}