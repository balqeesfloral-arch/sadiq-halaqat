import { useEffect, useState } from "react";
import { X, Save } from "lucide-react";

import AppSelect from "../AppSelect";
import ConfirmModal from "../ConfirmModal";
import { showToast } from "../toast";

import { supabase } from "../../lib/supabase";

export default function CreateAchievementModal({
  open,
  onClose,
  onSaved
}) {

  const [loading,setLoading] =
    useState(false);

  const [showCloseConfirm,setShowCloseConfirm] =
    useState(false);

  const [mosques,setMosques] =
    useState([]);

  const [halaqat,setHalaqat] =
    useState([]);

  const [teachers,setTeachers] =
    useState([]);

  const [students,setStudents] =
    useState([]);

  const [form,setForm] =
    useState({

      mosque_id:"",
      halaqa_id:"",
      teacher_id:"",
      student_id:"",

      progress_month:
      new Date()
      .toISOString()
      .slice(0,7),

      lesson_name:"",

      memorization_from_surah:"",
      memorization_from_ayah:"",

      memorization_to_surah:"",
      memorization_to_ayah:"",

      memorization_pages:"",
      memorization_completed:true,

      revision_from_surah:"",
      revision_from_ayah:"",

      revision_to_surah:"",
      revision_to_ayah:"",

      revision_pages:"",
      revision_completed:true,

      revision_from_surah:"",
      revision_from_ayah:"",

      revision_to_surah:"",
      revision_to_ayah:"",

      revision_pages:"",
      revision_completed:true,
      delay_reason:"",
      notes:""

    });

  useEffect(()=>{

    if(open){

      loadMosques();

    }

  },[open]);

  async function loadMosques(){

    const { data,error } =
      await supabase
      .from("mosques")
      .select("*")
      .order("name");

    if(error){

      showToast(
        error.message,
        "error"
      );

      return;
    }

    setMosques(
      data || []
    );

  }

  async function loadHalaqat(
    mosqueId
  ){

    setForm(prev=>({

      ...prev,
      mosque_id:mosqueId,
      halaqa_id:"",
      teacher_id:"",
      student_id:""

    }));

    const { data,error } =
      await supabase
      .from("halaqat")
      .select("*")
      .eq(
        "mosque_id",
        mosqueId
      )
      .order("name");

    if(error){

      showToast(
        error.message,
        "error"
      );

      return;
    }

    setHalaqat(
      data || []
    );

  }

  async function loadHalaqaData(
    halaqaId
  ){

    setForm(prev=>({

      ...prev,
      halaqa_id:halaqaId,
      teacher_id:"",
      student_id:""

    }));

    const teacherQuery =
      await supabase
      .from(
        "teacher_halaqat"
      )
      .select(`
        teacher_id,
        profiles(
          id,
          full_name
        )
      `)
      .eq(
        "halaqa_id",
        halaqaId
      );

    const studentQuery =
      await supabase
      .from(
        "student_halaqat"
      )
      .select(`
        student_id,
        profiles(
          id,
          full_name
        )
      `)
      .eq(
        "halaqa_id",
        halaqaId
      );

    if(
      teacherQuery.error ||
      studentQuery.error
    ){

      showToast(
        "فشل تحميل البيانات",
        "error"
      );

      return;
    }

    setTeachers(

      (teacherQuery.data || [])
      .map(item=>({

        id:item.teacher_id,

        full_name:
        item.profiles
        ?.full_name

      }))

    );

    const uniqueStudents =
      Array.from(

        new Map(

          (
            studentQuery.data
            || []
          ).map(item=>

            [

              item.student_id,

              {
                id:
                item.student_id,

                full_name:
                item.profiles
                ?.full_name
              }

            ]

          )

        ).values()

      );

    setStudents(
      uniqueStudents
    );

  }

const inputStyle = {

  width:"100%",
  height:"48px",
  border:"1px solid #CBD5E1",
  borderRadius:"12px",
  padding:"0 12px",
  marginBottom:"12px",
  boxSizing:"border-box"

};

async function saveAchievement(){

  try{

    setLoading(true);

    if(
      !form.mosque_id ||
      !form.halaqa_id ||
      !form.teacher_id ||
      !form.student_id
    ){

      showToast(
        "أكمل البيانات المطلوبة",
        "error"
      );

      return;
    }

    const payload = {

      mosque_id:
      form.mosque_id,

      halaqa_id:
      form.halaqa_id,

      teacher_id:
      form.teacher_id,

      progress_month:
      `${form.progress_month}-01`,

      lesson_name:
      form.lesson_name,

      memorization_from_surah:
      form.memorization_from_surah,

      memorization_from_ayah:
      Number(
        form.memorization_from_ayah
      ) || null,

      memorization_to_surah:
      form.memorization_to_surah,

      memorization_to_ayah:
      Number(
        form.memorization_to_ayah
      ) || null,

      memorization_pages:
      Number(
        form.memorization_pages
      ) || 0,

      memorization_completed:
      form.memorization_completed,

      revision_from_surah:
      form.revision_from_surah,

      revision_from_ayah:
      Number(
        form.revision_from_ayah
      ) || null,

      revision_to_surah:
      form.revision_to_surah,

      revision_to_ayah:
      Number(
        form.revision_to_ayah
      ) || null,

      revision_pages:
      Number(
        form.revision_pages
      ) || 0,

      revision_completed:
      form.revision_completed,

      delay_reason:
      form.delay_reason,

      notes:
      form.notes

    };

    if(form.student_id === "all"){

  if(students.length === 0){

    showToast(
      "لا يوجد طلاب",
      "error"
    );

    return;
  }

  const rows =
    students.map(student => ({

      ...payload,

      student_id:
      student.id

    }));

  const { error } =
    await supabase
    .from("monthly_progress")
    .insert(rows);

  if(error)
    throw error;

}
else{

  const { error } =
    await supabase
    .from("monthly_progress")
    .insert([
      {
        ...payload,
        student_id:
        form.student_id
      }
    ]);

  if(error)
    throw error;

}

    showToast(
      "تم حفظ الإنجاز الشهري بنجاح",
      "success"
    );

    onSaved?.();

setForm(initialState);

    onClose?.();

  }

  catch(error){

    showToast(
      error.message,
      "error"
    );

  }

  finally{

    setLoading(false);

  }

}

  if(!open)
    return null;

const progress =

(form.memorization_completed
 ? 50
 : 0)

+

(form.revision_completed
 ? 50
 : 0);

return (

  <>
  
    <div
      style={{
        position:"fixed",
        inset:0,
        background:"rgba(0,0,0,.45)",
        display:"flex",
        justifyContent:"center",
        alignItems:"center",
        zIndex:9999
      }}
    >

      <div
        style={{
          width:"95%",
          maxWidth:"1400px",
          maxHeight:"92vh",
          overflowY:"auto",
          background:"#fff",
          borderRadius:"28px",
          padding:"32px",
          boxShadow:
          "0 20px 60px rgba(0,0,0,.15)"
        }}
      >

        <div
          style={{
            display:"flex",
            justifyContent:"space-between",
            alignItems:"center",
            marginBottom:"25px"
          }}
        >

          <div>

            <h2
              style={{
                margin:0
              }}
            >
              إنشاء إنجاز شهري
            </h2>

            <div
              style={{
                color:"#64748B",
                marginTop:"6px"
              }}
            >
              تسجيل حفظ ومراجعة الطلاب
            </div>

          </div>

          <button
            onClick={()=>
              setShowCloseConfirm(true)
            }
            style={{
              border:"none",
              background:"#F8FAFC",
              width:"44px",
              height:"44px",
              borderRadius:"12px",
              cursor:"pointer"
            }}
          >
            <X size={20}/>
          </button>

        </div>



        <div
          style={{
  display:"grid",
  gridTemplateColumns:
    "repeat(auto-fit,minmax(250px,1fr))",
  gap:"16px",
  marginBottom:"24px"
}}
        >

          <AppSelect
            label="المسجد"
            value={form.mosque_id}
            onChange={loadHalaqat}
            options={

              mosques.map(m=>({

                label:m.name,
                value:m.id

              }))

            }
          />

          <AppSelect
            label="الحلقة"
            value={form.halaqa_id}
            onChange={loadHalaqaData}
            options={

              halaqat.map(h=>({

                label:h.name,
                value:h.id

              }))

            }
          />

          <AppSelect
            label="المعلم"
            value={form.teacher_id}
            onChange={(value)=>

              setForm(prev=>({

                ...prev,
                teacher_id:value

              }))

            }
            options={

              teachers.map(t=>({

                label:t.full_name,
                value:t.id

              }))

            }
          />

          <AppSelect
  label="الطالب"
  value={form.student_id}
  onChange={(value)=>
    setForm(prev=>({
      ...prev,
      student_id:value
    }))
  }
  options={[
    {
      label:"جميع الطلاب",
      value:"all"
    },
    ...students.map(s=>({
      label:s.full_name,
      value:s.id
    }))
  ]}
/>

{form.halaqa_id && (

  <div
    style={{
      gridColumn:"1 / -1",
      background:"#F8FAFC",
      border:"1px solid #E2E8F0",
      borderRadius:"18px",
      padding:"18px",
      marginTop:"8px"
    }}
  >

    <div
      style={{
        display:"grid",
        gridTemplateColumns:
        "repeat(auto-fit,minmax(220px,1fr))",
        gap:"16px"
      }}
    >

      <div>
        <div style={{color:"#94A3B8"}}>
          الحلقة
        </div>
        <strong>
          {
            halaqat.find(
              h=>h.id == form.halaqa_id
            )?.name
          }
        </strong>
      </div>

      <div>
        <div style={{color:"#94A3B8"}}>
          المعلم
        </div>
        <strong>
          {
            teachers.find(
              t=>t.id == form.teacher_id
            )?.full_name || "-"
          }
        </strong>
      </div>

      <div>
        <div style={{color:"#94A3B8"}}>
          عدد الطلاب
        </div>
        <strong>
          {students.length}
        </strong>
      </div>

    </div>

  </div>

)}
            value={form.student_id}
            onChange={(value)=>

              setForm(prev=>({

                ...prev,
                student_id:value

              }))

            }
            options={[

              {
                label:"جميع الطلاب",
                value:"all"
              },

              ...students.map(s=>({

                label:s.full_name,
                value:s.id

              }))

            ]}
          />

        </div>

        <div
          style={{
            display:"grid",
gridTemplateColumns:
"repeat(auto-fit,minmax(450px,1fr))"
            gap:"24px"
          }}
        >

          <div
            style={{
              border:"1px solid #E2E8F0",
              borderRadius:"22px",
              padding:"20px"
            }}
          >

<input
  type="month"
  value={form.progress_month}
  onChange={(e)=>
    setForm(prev=>({
      ...prev,
      progress_month:e.target.value
    }))
  }
  style={inputStyle}
/>

            <h3>
              الحفظ
            </h3>

            <input
              placeholder="اسم الدرس"
              value={form.lesson_name}
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  lesson_name:
                  e.target.value

                }))

              }
              style={inputStyle}
            />

            <input
              placeholder="من سورة"
              value={
                form.memorization_from_surah
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  memorization_from_surah:
                  e.target.value

                }))

              }
              style={inputStyle}
            />
<input
  type="number"
  placeholder="من آية"
  value={
    form.memorization_from_ayah
  }
  onChange={(e)=>
    setForm(prev=>({
      ...prev,
      memorization_from_ayah:
      e.target.value
    }))
  }
  style={inputStyle}
/>

            <input
              placeholder="إلى سورة"
              value={
                form.memorization_to_surah
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  memorization_to_surah:
                  e.target.value

                }))

              }
              style={inputStyle}
            />
<input
  type="number"
  placeholder="إلى آية"
  value={
    form.memorization_to_ayah
  }
  onChange={(e)=>
    setForm(prev=>({
      ...prev,
      memorization_to_ayah:
      e.target.value
    }))
  }
  style={inputStyle}
/>

            <input
              type="number"
              placeholder="عدد الأوجه"
              value={
                form.memorization_pages
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  memorization_pages:
                  e.target.value

                }))

              }
              style={inputStyle}
            />

            <label>

              <input
                type="checkbox"
                checked={
                  form
                  .memorization_completed
                }
                onChange={(e)=>

                  setForm(prev=>({

                    ...prev,
                    memorization_completed:
                    e.target.checked

                  }))

                }
              />

              تم الإنجاز

            </label>

          </div>

          <div
            style={{
              border:"1px solid #E2E8F0",
              borderRadius:"22px",
              padding:"20px"
            }}
          >

            <h3>
              المراجعة
            </h3>

            <input
              placeholder="من سورة"
              value={
                form.revision_from_surah
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  revision_from_surah:
                  e.target.value

                }))

              }
              style={inputStyle}
            />

<input
  type="number"
  placeholder="من آية"
  value={
    form.memorization_from_ayah
  }
  onChange={(e)=>
    setForm(prev=>({
      ...prev,
      memorization_from_ayah:
      e.target.value
    }))
  }
  style={inputStyle}
/> 

            <input
              placeholder="إلى سورة"
              value={
                form.revision_to_surah
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  revision_to_surah:
                  e.target.value

                }))

              }
              style={inputStyle}
            />

<input
  type="number"
  placeholder="إلى آية"
  value={
    form.memorization_to_ayah
  }
  onChange={(e)=>
    setForm(prev=>({
      ...prev,
      memorization_to_ayah:
      e.target.value
    }))
  }
  style={inputStyle}
/>

            <input
              type="number"
              placeholder="عدد الأوجه"
              value={
                form.revision_pages
              }
              onChange={(e)=>

                setForm(prev=>({

                  ...prev,
                  revision_pages:
                  e.target.value

                }))

              }
              style={inputStyle}
            />

            <label>

              <input
                type="checkbox"
                checked={
                  form
                  .revision_completed
                }
                onChange={(e)=>

                  setForm(prev=>({

                    ...prev,
                    revision_completed:
                    e.target.checked

                  }))

                }
              />

              تم الإنجاز

            </label>

          </div>

        </div>
        {
          (
            !form.memorization_completed
            ||
            !form.revision_completed
          ) && (

            <div
              style={{
                marginTop:"24px",
                border:"1px solid #FECACA",
                background:"#FEF2F2",
                borderRadius:"20px",
                padding:"20px"
              }}
            >

              <h3
                style={{
                  marginTop:0,
                  color:"#991B1B"
                }}
              >
                سبب التعثر
              </h3>

              <textarea
                rows={4}
                value={form.delay_reason}
                onChange={(e)=>

                  setForm(prev=>({

                    ...prev,
                    delay_reason:
                    e.target.value

                  }))

                }
                placeholder="اكتب سبب التعثر..."
                style={{
                  width:"100%",
                  boxSizing:"border-box",
                  border:"1px solid #FCA5A5",
                  borderRadius:"14px",
                  padding:"12px"
                }}
              />

            </div>

          )
        }

        <div
          style={{
            marginTop:"24px"
          }}
        >

          <h3>
            ملاحظات
          </h3>

          <textarea
            rows={4}
            value={form.notes}
            onChange={(e)=>

              setForm(prev=>({

                ...prev,
                notes:e.target.value

              }))

            }
            placeholder="أي ملاحظات إضافية..."
            style={{
              width:"100%",
              boxSizing:"border-box",
              border:"1px solid #CBD5E1",
              borderRadius:"14px",
              padding:"12px"
            }}
          />

        </div>

        <div
          style={{
            display:"flex",
            gap:"12px",
            justifyContent:"flex-end",
            marginTop:"30px",
            paddingTop:"20px",
            borderTop:"1px solid #E2E8F0"
          }}
        >

          <button
            onClick={()=>
              setShowCloseConfirm(true)
            }
            style={{
              border:"1px solid #CBD5E1",
              background:"#fff",
              padding:"12px 18px",
              borderRadius:"12px",
              cursor:"pointer"
            }}
          >
            إلغاء
          </button>

          <button
            onClick={saveAchievement}
            disabled={loading}
            style={{
              background:"#0F766E",
              color:"#fff",
              border:"none",
              padding:"12px 20px",
              borderRadius:"12px",
              cursor:"pointer",
              display:"flex",
              alignItems:"center",
              gap:"8px"
            }}
          >

            <Save size={18}/>

            {
              loading
              ? "جاري الحفظ..."
              : "حفظ الإنجاز"
            }

          </button>

        </div>

      </div>

    </div>

    <ConfirmModal
      open={showCloseConfirm}
      title="إلغاء الإدخال؟"
      message="سيتم فقدان البيانات غير المحفوظة."
      onConfirm={onClose}
      onClose={()=>
        setShowCloseConfirm(false)
      }
    />

  </>
);

}

}