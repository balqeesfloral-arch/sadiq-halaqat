export default function AchievementStats({
  achievements = []
}) {

  const total =
    achievements.length;

  const memorizationCompleted =
    achievements.filter(
      a => a.memorization_completed
    ).length;

  const revisionCompleted =
    achievements.filter(
      a => a.revision_completed
    ).length;

  const delayed =
    achievements.filter(
      a =>
        !a.memorization_completed ||
        !a.revision_completed
    ).length;

  const memorizationRate =
    total
      ? Math.round(
          memorizationCompleted /
          total *
          100
        )
      : 0;

  const revisionRate =
    total
      ? Math.round(
          revisionCompleted /
          total *
          100
        )
      : 0;

  return (

    <div
      style={{
        display:"grid",
        gridTemplateColumns:
          "repeat(4,1fr)",
        gap:"16px",
        marginBottom:"24px"
      }}
    >

      <Card
        title="إجمالي الإنجازات"
        value={total}
      />

      <Card
        title="نسبة الحفظ"
        value={`${memorizationRate}%`}
      />

      <Card
        title="نسبة المراجعة"
        value={`${revisionRate}%`}
      />

      <Card
        title="المتعثرون"
        value={delayed}
      />

    </div>

  );

}

function Card({
  title,
  value
}) {

  return (

    <div
      style={{
        background:"#fff",
        border:"1px solid #E2E8F0",
        borderRadius:"22px",
        padding:"22px"
      }}
    >

      <div
        style={{
          color:"#64748B",
          marginBottom:"8px",
          fontWeight:"700"
        }}
      >
        {title}
      </div>

      <div
        style={{
          fontSize:"32px",
          fontWeight:"900",
          color:"#0F172A"
        }}
      >
        {value}
      </div>

    </div>

  );

}