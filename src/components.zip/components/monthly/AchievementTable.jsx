import { Eye, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import ConfirmModal from "../common/ConfirmModal";
import { showToast } from "../../utils/showToast";
import { supabase } from "../../lib/supabase";

export default function AchievementTable({
  achievements = [],
  onView,
  onEdit,
  onReload
}) {

  const [deleteId,setDeleteId] =
    useState(null);

  async function handleDelete() {

    if(!deleteId) return;

    const { error } =
      await supabase
      .from("monthly_progress")
      .delete()
      .eq("id",deleteId);

    if(error){

      showToast(
        error.message,
        "error"
      );

      return;
    }

    showToast(
      "تم حذف الإنجاز",
      "success"
    );

    setDeleteId(null);

    onReload?.();

  }

  return (

    <>
    
      <div
        style={{
          background:"#fff",
          borderRadius:"24px",
          overflow:"hidden",
          border:"1px solid #E2E8F0"
        }}
      >

        <div
          style={{
            display:"grid",
            gridTemplateColumns:
              "80px 2fr 1.5fr 1.5fr 1fr 1fr 140px",
            gap:"12px",
            padding:"18px 20px",
            background:"#F8FAFC",
            fontWeight:"800",
            color:"#0F172A"
          }}
        >
          <div>#</div>
          <div>الطالب</div>
          <div>الحلقة</div>
          <div>المعلم</div>
          <div>الحفظ</div>
          <div>المراجعة</div>
          <div>الإجراءات</div>
        </div>

        {

        achievements.length === 0 ?

        (

          <div
            style={{
              padding:"50px",
              textAlign:"center",
              color:"#94A3B8"
            }}
          >
            لا توجد بيانات
          </div>

        )

        :

        (

          achievements.map(
            (row,index)=>{

              return(

                <div
                  key={row.id}
                  style={{
                    display:"grid",
                    gridTemplateColumns:
                      "80px 2fr 1.5fr 1.5fr 1fr 1fr 140px",
                    gap:"12px",
                    padding:"18px 20px",
                    borderTop:
                      "1px solid #F1F5F9",
                    alignItems:"center"
                  }}
                >

                  <div>
                    {index + 1}
                  </div>

                  <div
                    style={{
                      fontWeight:"700"
                    }}
                  >
                    {
                      row.student
                      ?.full_name
                      ||
                      "-"
                    }
                  </div>

                  <div>
                    {
                      row.halaqa
                      ?.name
                      ||
                      "-"
                    }
                  </div>

                  <div>
                    {
                      row.teacher
                      ?.full_name
                      ||
                      "-"
                    }
                  </div>

                  <div>

                    <span
                      style={{
                        background:
                          row.memorization_completed
                          ? "#DCFCE7"
                          : "#FEE2E2",

                        color:
                          row.memorization_completed
                          ? "#166534"
                          : "#991B1B",

                        padding:
                          "6px 12px",

                        borderRadius:
                          "999px",

                        fontWeight:"700"
                      }}
                    >
                      {
                        row.memorization_completed
                        ? "مكتمل"
                        : "متعثر"
                      }
                    </span>

                  </div>

                  <div>

                    <span
                      style={{
                        background:
                          row.revision_completed
                          ? "#DBEAFE"
                          : "#FEF3C7",

                        color:
                          row.revision_completed
                          ? "#1D4ED8"
                          : "#92400E",

                        padding:
                          "6px 12px",

                        borderRadius:
                          "999px",

                        fontWeight:"700"
                      }}
                    >
                      {
                        row.revision_completed
                        ? "مكتملة"
                        : "متابعة"
                      }
                    </span>

                  </div>

                  <div
                    style={{
                      display:"flex",
                      gap:"8px"
                    }}
                  >

                    <button
                      onClick={()=>
                        onView?.(row)
                      }
                      style={btnStyle}
                    >
                      <Eye size={18}/>
                    </button>

                    <button
                      onClick={()=>
                        onEdit?.(row)
                      }
                      style={btnStyle}
                    >
                      <Pencil size={18}/>
                    </button>

                    <button
                      onClick={()=>
                        setDeleteId(
                          row.id
                        )
                      }
                      style={{
                        ...btnStyle,
                        color:"#DC2626"
                      }}
                    >
                      <Trash2 size={18}/>
                    </button>

                  </div>

                </div>

              );

            }
          )

        )

        }

      </div>

      <ConfirmModal
        open={!!deleteId}
        title="حذف الإنجاز"
        description="هل أنت متأكد من حذف الإنجاز؟"
        confirmText="حذف"
        cancelText="إلغاء"
        onConfirm={handleDelete}
        onClose={()=>
          setDeleteId(null)
        }
      />

    </>

  );

}

const btnStyle = {

  border:"none",
  background:"#F8FAFC",
  width:"38px",
  height:"38px",
  borderRadius:"10px",
  cursor:"pointer",
  display:"flex",
  justifyContent:"center",
  alignItems:"center"

};